library(testthat)
library(ConsensusClustering)

test_check("ConsensusClustering")
