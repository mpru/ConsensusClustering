## ---- tidy=TRUE----------------------------------------------------------
set.seed(0)
simData <- matrix(c(rnorm(40 * 500, mean = 0, sd = 0.02), rnorm(20 * 500, mean = 10, sd = 0.02), rnorm(40 * 500, mean = 20, sd = 0.02)),ncol = 100, nrow = 500)
row.names(simData) <- paste("feature:", 1:500, sep = "")
colnames(simData) <- paste("sample:", 1:100, sep = "")
simData[1:5,1:5]

## ---- message = FALSE, warning=FALSE-------------------------------------
library(ConsensusClustering)
library(doParallel)

cl <- makeCluster(2)
registerDoParallel(cl)
results <- consensusClustering(dataMatrix = simData, K = 3:5, nIters = 50, propSamples = 0.8, 
                               verbose = F, seed = 0, saveResults = F, plotHeatmaps = "no",
                               plotCDF = FALSE, consensusStatsPlots = F, plotTracking = FALSE)
stopCluster(cl)
names(results)

## ---- fig.show='hold', eval=FALSE----------------------------------------
#  PlotHeatmaps(results, showSamplesNames = F, showFeaturesNames = F, dataMatrix = simData)

## ------------------------------------------------------------------------
results$PACscores

## ---- fig.show='hold', eval=FALSE----------------------------------------
#  PlotCDF(results)

## ---- eval=F-------------------------------------------------------------
#  PlotTracking(results, showSamplesNames = F)

## ------------------------------------------------------------------------
results$consensusStats$clusterConsensus
head(results$consensusStats$itemConsensus)
results$consensusStats$intraInterCons

## ---- fig.show='hold',eval=F---------------------------------------------
#  stats <- ConsensusStatsAndPlots(results)

